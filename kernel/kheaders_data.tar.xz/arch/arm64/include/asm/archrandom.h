/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_ARCHRANDOM_H
#define _ASM_ARCHRANDOM_H

#ifdef CONFIG_ARCH_RANDOM

#include <linux/bug.h>
#include <linux/kernel.h>
#include <asm/cpufeature.h>

static inline bool __arm64_rndr(unsigned long *v)
{
	bool ok;

	
	asm volatile(
		__mrs_s("%0", SYS_RNDR_EL0) "\n"
	"	cset %w1, ne\n"
	: "=r" (*v), "=r" (ok)
	:
	: "cc");

	return ok;
}

static inline bool __must_check arch_get_random_long(unsigned long *v)
{
	return false;
}

static inline bool __must_check arch_get_random_int(unsigned int *v)
{
	return false;
}

static inline bool __must_check arch_get_random_seed_long(unsigned long *v)
{
	
	if (!cpus_have_const_cap(ARM64_HAS_RNG))
		return false;

	return __arm64_rndr(v);
}


static inline bool __must_check arch_get_random_seed_int(unsigned int *v)
{
	unsigned long val;
	bool ok = arch_get_random_seed_long(&val);

	*v = val;
	return ok;
}

static inline bool __init __early_cpu_has_rndr(void)
{
	
	unsigned long ftr = read_sysreg_s(SYS_ID_AA64ISAR0_EL1);
	return (ftr >> ID_AA64ISAR0_RNDR_SHIFT) & 0xf;
}

static inline bool __init __must_check
arch_get_random_seed_long_early(unsigned long *v)
{
	WARN_ON(system_state != SYSTEM_BOOTING);

	if (!__early_cpu_has_rndr())
		return false;

	return __arm64_rndr(v);
}
#define arch_get_random_seed_long_early arch_get_random_seed_long_early

#endif 
#endif 
