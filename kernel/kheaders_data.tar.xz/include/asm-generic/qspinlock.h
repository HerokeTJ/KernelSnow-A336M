/* SPDX-License-Identifier: GPL-2.0-or-later */

#ifndef __ASM_GENERIC_QSPINLOCK_H
#define __ASM_GENERIC_QSPINLOCK_H

#include <asm-generic/qspinlock_types.h>
#include <linux/atomic.h>

#ifndef queued_spin_is_locked

static __always_inline int queued_spin_is_locked(struct qspinlock *lock)
{
	
	return atomic_read(&lock->val);
}
#endif


static __always_inline int queued_spin_value_unlocked(struct qspinlock lock)
{
	return !atomic_read(&lock.val);
}


static __always_inline int queued_spin_is_contended(struct qspinlock *lock)
{
	return atomic_read(&lock->val) & ~_Q_LOCKED_MASK;
}

#ifdef CONFIG_SEC_DEBUG_QSPIN_OWNER
static __always_inline u8 __queued_spin_get_locked_val(void)
{
	int cpu = raw_smp_processor_id();
	return (cpu << _Q_OWNER_OFFSET) | _Q_DBGEN_VAL | _Q_LOCKED_VAL;
}
#endif


static __always_inline int queued_spin_trylock(struct qspinlock *lock)
{
	u32 val = atomic_read(&lock->val);

	if (unlikely(val))
		return 0;

#ifdef CONFIG_SEC_DEBUG_QSPIN_OWNER
	return likely(atomic_try_cmpxchg_acquire(&lock->val, &val, __queued_spin_get_locked_val()));
#else
	return likely(atomic_try_cmpxchg_acquire(&lock->val, &val, _Q_LOCKED_VAL));
#endif
}

extern void queued_spin_lock_slowpath(struct qspinlock *lock, u32 val);

#ifndef queued_spin_lock

static __always_inline void queued_spin_lock(struct qspinlock *lock)
{
	u32 val = 0;

#ifdef CONFIG_SEC_DEBUG_QSPIN_OWNER
	if (likely(atomic_try_cmpxchg_acquire(&lock->val, &val, __queued_spin_get_locked_val())))
#else
	if (likely(atomic_try_cmpxchg_acquire(&lock->val, &val, _Q_LOCKED_VAL)))
#endif
		return;

	queued_spin_lock_slowpath(lock, val);
}
#endif

#ifndef queued_spin_unlock

static __always_inline void queued_spin_unlock(struct qspinlock *lock)
{
	
	smp_store_release(&lock->locked, 0);
}
#endif

#ifndef virt_spin_lock
static __always_inline bool virt_spin_lock(struct qspinlock *lock)
{
	return false;
}
#endif


#define arch_spin_is_locked(l)		queued_spin_is_locked(l)
#define arch_spin_is_contended(l)	queued_spin_is_contended(l)
#define arch_spin_value_unlocked(l)	queued_spin_value_unlocked(l)
#define arch_spin_lock(l)		queued_spin_lock(l)
#define arch_spin_trylock(l)		queued_spin_trylock(l)
#define arch_spin_unlock(l)		queued_spin_unlock(l)

#endif 
