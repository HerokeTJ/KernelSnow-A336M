

#ifndef _FMP_HMAC_SHA256_H
#define _FMP_HMAC_SHA256_H

#include "sha256.h"

struct hmac_sha256_ctx {
	struct fmp_shash_desc inner_ctx;
	struct fmp_shash_desc outer_ctx;
};

typedef struct hmac_sha256_ctx HMAC_SHA256_CTX;


int hmac_sha256_init(struct hmac_sha256_ctx *ctx, const u8 *key, unsigned int key_len);


int hmac_sha256_update(struct hmac_sha256_ctx *ctx, const u8 *data, unsigned int data_len);


int hmac_sha256_final(struct hmac_sha256_ctx *ctx, u8 *out);


int hmac_sha256(const u8 *key, unsigned int key_len, const u8 *data, unsigned int data_len, u8 *out);


void hmac_sha256_ctx_cleanup(struct hmac_sha256_ctx *ctx);

#endif 

