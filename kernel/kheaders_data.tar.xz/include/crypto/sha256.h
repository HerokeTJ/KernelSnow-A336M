

#ifndef SHA256_FMP_H
#define SHA256_FMP_H

#include <linux/types.h>

#define SHA256_DIGEST_SIZE      32
#define SHA256_BLOCK_SIZE       64
#define SHA256_DIGEST_LENGTH  SHA256_DIGEST_SIZE

struct sha256_state {
	u32 state[SHA256_DIGEST_SIZE / 4];
	u64 count;
	u8 buf[SHA256_BLOCK_SIZE];
};

struct fmp_shash_desc {
	struct sha256_state __ctx;
};

typedef struct fmp_shash_desc SHA256_CTX;

typedef void (sha256_block_fn)(struct sha256_state *sst, u8 const *src,
			int blocks);


int fmp_sha256_init(struct fmp_shash_desc *desc);


int fmp_sha256_update(struct fmp_shash_desc *desc, const u8 *data,
			unsigned int len);


int fmp_sha256_final(struct fmp_shash_desc *desc, u8 *out);


int fmp_sha256(const u8 *data, unsigned int len, u8 *out);


int fmp_sha256_desc_copy(struct fmp_shash_desc *dst, const struct fmp_shash_desc *src);

#endif  
